public enum ProjectEmployeeType {
    MANAGER,
    EMPLOYEE
}
